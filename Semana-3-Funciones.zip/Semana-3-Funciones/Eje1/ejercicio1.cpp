#include <iostream>
using namespace std;

// Función para leer números
void leerNumeros(int &a, int &b, int &c) {
    cout << "Ingrese el primer numero: ";
    cin >> a;

    cout << "Ingrese el segundo numero: ";
    cin >> b;

    cout << "Ingrese el tercer numero: ";
    cin >> c;
}

// Función que calcula la suma
int calcularSuma(int a, int b, int c) {
    return a + b + c;
}

// Función que calcula promedio
double calcularPromedio(int suma) {
    return suma / 3.0;
}

// Función para mostrar resultados
void mostrarResultados(int suma, double promedio) {
    cout << "\nSuma: " << suma << endl;
    cout << "Promedio: " << promedio << endl;
}


int main() {

    int num1, num2, num3;

    leerNumeros(num1, num2, num3);

    int suma = calcularSuma(num1, num2, num3);

    double promedio = calcularPromedio(suma);

    mostrarResultados(suma, promedio);

    return 0;
}