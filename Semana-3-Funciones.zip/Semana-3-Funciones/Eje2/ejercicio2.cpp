#include <iostream>
using namespace std;


// Leer datos
void leerDatos(int &a, int &b) {

    cout << "Ingrese el primer numero: ";
    cin >> a;

    cout << "Ingrese el segundo numero: ";
    cin >> b;
}


// Comparar números
int compararValores(int a, int b) {

    if(a > b)
        return 1;

    else if(b > a)
        return -1;

    else
        return 0;
}


// Mostrar resultado
void mostrarResultado(int resultado) {

    if(resultado == 1)
        cout << "El primer numero es mayor." << endl;

    else if(resultado == -1)
        cout << "El segundo numero es mayor." << endl;

    else
        cout << "Ambos numeros son iguales." << endl;
}



int main() {

    int numero1, numero2;

    leerDatos(numero1, numero2);

    int resultado = compararValores(numero1, numero2);

    mostrarResultado(resultado);


    return 0;
}