#include <iostream>
using namespace std;


// Leer base y altura
void leerDatos(double &base, double &altura){

    cout << "Ingrese la base del rectangulo: ";
    cin >> base;

    cout << "Ingrese la altura del rectangulo: ";
    cin >> altura;

}


// Calcular área
double calcularArea(double base, double altura){

    return base * altura;

}


// Mostrar resultado
void mostrarArea(double area){

    cout << "El area del rectangulo es: "
         << area << endl;

}



int main(){

    double base, altura;


    leerDatos(base, altura);


    double area = calcularArea(base, altura);


    mostrarArea(area);


    return 0;
}