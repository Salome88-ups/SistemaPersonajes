#include <iostream>
using namespace std;


// Intercambiar valores
void intercambiar(int &a, int &b){

    int auxiliar = a;

    a = b;

    b = auxiliar;

}


// Mostrar números
void mostrarValores(int a, int b){

    cout << "Numero 1: " << a << endl;
    cout << "Numero 2: " << b << endl;

}



int main(){

    int numero1, numero2;


    cout << "Ingrese numero 1: ";
    cin >> numero1;


    cout << "Ingrese numero 2: ";
    cin >> numero2;



    cout << "\nAntes del intercambio:" << endl;

    mostrarValores(numero1, numero2);



    intercambiar(numero1, numero2);



    cout << "\nDespues del intercambio:" << endl;

    mostrarValores(numero1, numero2);



    return 0;
}