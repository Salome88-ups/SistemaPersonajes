#include <iostream>
using namespace std;


// Actualizar contador
void incrementarContador(int &contador){

    contador++;

}


// Leer número
int leerNumero(){

    int n;

    cout << "Ingrese un numero positivo: ";
    cin >> n;

    return n;

}


// Mostrar contador
void mostrarContador(int contador){

    cout << "Contador: " << contador << endl;

}



int main(){

    int n = leerNumero();

    int contador = 0;



    while(contador < n){

        incrementarContador(contador);

        mostrarContador(contador);

    }



    return 0;
}