# Semana 3 - Funciones en C++

## Tema
Funciones, parámetros, retorno y modularización.

## Ejercicios realizados

### Ejercicio 1
Suma y promedio de tres números utilizando funciones.

### Ejercicio 2
Comparación de dos números para determinar el mayor.

### Ejercicio 3
Cálculo del área de un rectángulo usando valores reales.

### Ejercicio 4
Intercambio de valores utilizando paso por referencia.

### Ejercicio 5
Actualización de contador utilizando referencia.

## Lenguaje utilizado
C++

## Autor
"Salome Rivadeneira"